# Features
1. change spaced repetition to avoid long delays in showing new words or final Reviewing words due to standard deviation
2. handle dark mode colors
