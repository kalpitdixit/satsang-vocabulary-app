# Features
1. make it dark mode compatible
2. avoid tail distribution of std dev based weighting for last few words 
